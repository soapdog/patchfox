window.$docsify = {
    name: "Patchfox Help",
    repo: "soapdog/patchfox",
    basePath: typeof browser !== "undefined" ? "/docs/" : "",
    loadSidebar: true,
    coverpage: true
}
