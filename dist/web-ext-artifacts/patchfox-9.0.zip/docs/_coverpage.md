<!-- _coverpage.md -->

![logo](_media/icon.png ':size=150')

# Patchfox

> A client for [Secure Scuttlebutt](https://scuttlebutt.nz) as a Firefox WebExtension.

- Simple and lightweight 

[GitHub](https://github.com/soapdog/patchfox/)
[Get Started](#readme)
