# Troubleshooting
These are the most common problems you might encounter when using Patchfox. If whatever you're facing is not covered here, please [file an issue on our Github repository](https://github.com/soapdog/patchfox/issues).

* [No Configuration](troubleshooting/no-configuration.md)
* [Can't Connect To sbot](troubleshooting/no-configuration.md)
