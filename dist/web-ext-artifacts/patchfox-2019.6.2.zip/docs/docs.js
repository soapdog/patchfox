window.$docsify = {
  name: "Patchfox Help",
  repo: "soapdog/patchfox",
  basePath: typeof browser !== "undefined" ? "/docs/" : "",
  loadSidebar: true,
  coverpage: typeof browser !== "undefined" ? false : true,
  subMaxLevel: 2
}
