<!-- _coverpage.md -->

![logo](_media/icon.png ':size=150')

# Patchfox

> A client for [Secure Scuttlebutt](https://scuttlebutt.nz) as a Firefox WebExtension.

- Simple and lightweight 

[GitHub](https://github.com/soapdog/patchfox/)
[Patchfox Open Collective](https://opencollective.com/patchfox)
[Documentation](#readme)
[Install from Firefox Add-ons](https://addons.mozilla.org/en-US/firefox/addon/patchfox/)
